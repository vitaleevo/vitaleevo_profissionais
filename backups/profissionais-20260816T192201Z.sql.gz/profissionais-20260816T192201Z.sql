--
-- PostgreSQL database dump
--

\restrict 9fWnEUrcHTO6YXshs0WkM5dWTtgTbgZdiCuGfYNWIaTryrAheePuLkzdroJ0PDu

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_attachments (
    id bigint NOT NULL,
    blob_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    name character varying NOT NULL,
    record_id bigint NOT NULL,
    record_type character varying NOT NULL
);


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_attachments_id_seq OWNED BY public.active_storage_attachments.id;


--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_blobs (
    id bigint NOT NULL,
    byte_size bigint NOT NULL,
    checksum character varying,
    content_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    filename character varying NOT NULL,
    key character varying NOT NULL,
    metadata text,
    service_name character varying NOT NULL
);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_blobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_blobs_id_seq OWNED BY public.active_storage_blobs.id;


--
-- Name: active_storage_variant_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_storage_variant_records (
    id bigint NOT NULL,
    blob_id bigint NOT NULL,
    variation_digest character varying NOT NULL
);


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_storage_variant_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_storage_variant_records_id_seq OWNED BY public.active_storage_variant_records.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    actor_id bigint,
    action character varying NOT NULL,
    auditable_type character varying,
    auditable_id bigint,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id bigint NOT NULL,
    address character varying,
    company_name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    email character varying,
    latitude numeric(10,6),
    longitude numeric(10,6),
    municipality character varying,
    name character varying NOT NULL,
    neighborhood character varying,
    phone character varying NOT NULL,
    province character varying,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint
);


--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    body text,
    channel character varying DEFAULT 'email'::character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    event character varying NOT NULL,
    read_at timestamp(6) without time zone,
    recipient_name character varying NOT NULL,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    amount_cents integer DEFAULT 0 NOT NULL,
    commission_cents integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    method character varying DEFAULT 'multicaixa_express'::character varying NOT NULL,
    paid_at timestamp(6) without time zone,
    professional_payout_cents integer DEFAULT 0 NOT NULL,
    service_request_id bigint NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT payments_split_matches_amount CHECK (((commission_cents + professional_payout_cents) = amount_cents))
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: professional_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.professional_documents (
    id bigint NOT NULL,
    byte_size integer NOT NULL,
    content_type character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    kind character varying NOT NULL,
    original_filename character varying NOT NULL,
    professional_id bigint NOT NULL,
    review_notes text,
    reviewed_at timestamp(6) without time zone,
    reviewed_by_id bigint,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: professional_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.professional_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professional_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.professional_documents_id_seq OWNED BY public.professional_documents.id;


--
-- Name: professional_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.professional_services (
    id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    professional_id bigint NOT NULL,
    service_category_id bigint NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: professional_services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.professional_services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professional_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.professional_services_id_seq OWNED BY public.professional_services.id;


--
-- Name: professionals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.professionals (
    id bigint NOT NULL,
    bio text,
    communication_rating numeric(3,2) DEFAULT 0.0 NOT NULL,
    completed_jobs integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    documents_status character varying DEFAULT 'pending'::character varying NOT NULL,
    email character varying,
    experience_years integer DEFAULT 0 NOT NULL,
    hourly_rate_cents integer DEFAULT 0 NOT NULL,
    latitude numeric(10,6),
    location character varying NOT NULL,
    longitude numeric(10,6),
    municipality character varying,
    name character varying NOT NULL,
    neighborhood character varying,
    phone character varying NOT NULL,
    province character varying,
    punctuality_rating numeric(3,2) DEFAULT 0.0 NOT NULL,
    quality_rating numeric(3,2) DEFAULT 0.0 NOT NULL,
    rating numeric(3,2) DEFAULT 0.0 NOT NULL,
    response_minutes integer DEFAULT 30 NOT NULL,
    specialty character varying NOT NULL,
    status character varying DEFAULT 'offline'::character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint,
    operator_notes text
);


--
-- Name: professionals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.professionals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: professionals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.professionals_id_seq OWNED BY public.professionals.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id bigint NOT NULL,
    client_id bigint NOT NULL,
    comment text,
    communication integer DEFAULT 5 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    professional_id bigint NOT NULL,
    punctuality integer DEFAULT 5 NOT NULL,
    quality integer DEFAULT 5 NOT NULL,
    service_request_id bigint NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_categories (
    id bigint NOT NULL,
    average_duration_minutes integer DEFAULT 60 NOT NULL,
    base_price_cents integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    description text,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    urgent_available boolean DEFAULT true NOT NULL
);


--
-- Name: service_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_categories_id_seq OWNED BY public.service_categories.id;


--
-- Name: service_request_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_request_attachments (
    id bigint NOT NULL,
    byte_size integer NOT NULL,
    content_type character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    original_filename character varying NOT NULL,
    service_request_id bigint NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: service_request_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_request_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_request_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_request_attachments_id_seq OWNED BY public.service_request_attachments.id;


--
-- Name: service_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_requests (
    id bigint NOT NULL,
    accepted_at timestamp(6) without time zone,
    budget_cents integer DEFAULT 0 NOT NULL,
    client_id bigint NOT NULL,
    code character varying NOT NULL,
    completed_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    description text NOT NULL,
    latitude numeric(10,6),
    location character varying NOT NULL,
    longitude numeric(10,6),
    municipality character varying,
    neighborhood character varying,
    operator_notes text,
    professional_id bigint,
    province character varying,
    scheduled_at timestamp(6) without time zone,
    service_category_id bigint NOT NULL,
    started_at timestamp(6) without time zone,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    title character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    urgency character varying DEFAULT 'normal'::character varying NOT NULL
);


--
-- Name: service_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_requests_id_seq OWNED BY public.service_requests.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    remember_created_at timestamp(6) without time zone,
    reset_password_sent_at timestamp(6) without time zone,
    reset_password_token character varying,
    role character varying DEFAULT 'client'::character varying NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: active_storage_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments ALTER COLUMN id SET DEFAULT nextval('public.active_storage_attachments_id_seq'::regclass);


--
-- Name: active_storage_blobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_blobs ALTER COLUMN id SET DEFAULT nextval('public.active_storage_blobs_id_seq'::regclass);


--
-- Name: active_storage_variant_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records ALTER COLUMN id SET DEFAULT nextval('public.active_storage_variant_records_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: professional_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_documents ALTER COLUMN id SET DEFAULT nextval('public.professional_documents_id_seq'::regclass);


--
-- Name: professional_services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_services ALTER COLUMN id SET DEFAULT nextval('public.professional_services_id_seq'::regclass);


--
-- Name: professionals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professionals ALTER COLUMN id SET DEFAULT nextval('public.professionals_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: service_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories ALTER COLUMN id SET DEFAULT nextval('public.service_categories_id_seq'::regclass);


--
-- Name: service_request_attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_request_attachments ALTER COLUMN id SET DEFAULT nextval('public.service_request_attachments_id_seq'::regclass);


--
-- Name: service_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests ALTER COLUMN id SET DEFAULT nextval('public.service_requests_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: active_storage_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.active_storage_attachments (id, blob_id, created_at, name, record_id, record_type) FROM stdin;
\.


--
-- Data for Name: active_storage_blobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.active_storage_blobs (id, byte_size, checksum, content_type, created_at, filename, key, metadata, service_name) FROM stdin;
\.


--
-- Data for Name: active_storage_variant_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.active_storage_variant_records (id, blob_id, variation_digest) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2026-06-03 00:58:54.735062	2026-06-03 00:58:54.735094
schema_sha1	672b278e53cae69d8bcb595562490c4214ff9e39	2026-06-03 00:58:54.755539	2026-06-03 00:58:54.755544
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_id, action, auditable_type, auditable_id, metadata, created_at, updated_at) FROM stdin;
52	528	service_request.assigned	ServiceRequest	186	{"next_status": "assigned", "previous_status": "pending", "professional_id": 389, "previous_professional_id": null}	2026-08-16 16:53:40.539593	2026-08-16 16:53:40.539593
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, address, company_name, created_at, email, latitude, longitude, municipality, name, neighborhood, phone, province, updated_at, user_id) FROM stdin;
165	Condominio Atlantico, Talatona	\N	2026-08-16 16:53:34.107861	ana.manuel@example.com	-8.918200	13.185000	Talatona	Ana Manuel	Talatona	+244 934 200 100	Luanda	2026-08-16 16:53:39.192847	540
166	Rua Major Kanhangulo, Ingombota	Kiala Comercio & Distribuicao	2026-08-16 16:53:34.133902	operacoes@kiala.co.ao	-8.814000	13.231400	Ingombota	Kiala Comercio & Distribuicao	Ingombota	+244 934 200 200	Luanda	2026-08-16 16:53:39.592001	541
167	Avenida 21 de Janeiro, Morro Bento	Clinica Luanda Care	2026-08-16 16:53:34.145801	direcao@luandacare.co.ao	-8.885000	13.201000	Talatona	Clinica Luanda Care	Morro Bento	+244 934 200 400	Luanda	2026-08-16 16:53:39.947274	542
168	Estrada de Catete, Viana	AutoAngola Concessionaria	2026-08-16 16:53:34.15866	vendas@autoangola.co.ao	-8.901000	13.365000	Viana	AutoAngola Concessionaria	Viana	+244 934 200 500	Luanda	2026-08-16 16:53:40.364639	543
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, body, channel, created_at, event, read_at, recipient_name, title, updated_at) FROM stdin;
124	Base corporativa Vitaleevo inicializada com sucesso: formacao, outsourcing, academia e limpeza corporativa.	email	2026-08-16 16:53:40.551412	daily_summary	\N	Operacao Vitaleevo	Resumo Operacional Vitaleevo	2026-08-16 16:53:40.551412
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, amount_cents, commission_cents, created_at, method, paid_at, professional_payout_cents, service_request_id, status, updated_at) FROM stdin;
121	85000000	12750000	2026-08-16 16:53:40.478168	multicaixa_express	2026-08-16 13:53:40.476122	72250000	187	paid	2026-08-16 16:53:40.478168
\.


--
-- Data for Name: professional_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.professional_documents (id, byte_size, content_type, created_at, kind, original_filename, professional_id, review_notes, reviewed_at, reviewed_by_id, status, updated_at) FROM stdin;
\.


--
-- Data for Name: professional_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.professional_services (id, created_at, professional_id, service_category_id, updated_at) FROM stdin;
493	2026-08-16 16:53:33.579086	389	235	2026-08-16 16:53:33.579086
494	2026-08-16 16:53:33.595463	389	241	2026-08-16 16:53:33.595463
495	2026-08-16 16:53:33.612206	389	244	2026-08-16 16:53:33.612206
496	2026-08-16 16:53:33.660204	390	239	2026-08-16 16:53:33.660204
497	2026-08-16 16:53:33.674503	390	240	2026-08-16 16:53:33.674503
498	2026-08-16 16:53:33.685158	390	248	2026-08-16 16:53:33.685158
499	2026-08-16 16:53:33.72728	391	238	2026-08-16 16:53:33.72728
500	2026-08-16 16:53:33.744605	391	245	2026-08-16 16:53:33.744605
501	2026-08-16 16:53:33.784445	392	243	2026-08-16 16:53:33.784445
502	2026-08-16 16:53:33.835554	393	249	2026-08-16 16:53:33.835554
503	2026-08-16 16:53:33.84431	393	244	2026-08-16 16:53:33.84431
504	2026-08-16 16:53:33.891567	394	236	2026-08-16 16:53:33.891567
505	2026-08-16 16:53:33.901287	394	242	2026-08-16 16:53:33.901287
506	2026-08-16 16:53:33.944132	395	237	2026-08-16 16:53:33.944132
507	2026-08-16 16:53:33.953772	395	242	2026-08-16 16:53:33.953772
508	2026-08-16 16:53:33.997511	396	235	2026-08-16 16:53:33.997511
509	2026-08-16 16:53:34.004977	396	245	2026-08-16 16:53:34.004977
510	2026-08-16 16:53:34.014228	396	244	2026-08-16 16:53:34.014228
511	2026-08-16 16:53:34.076917	397	247	2026-08-16 16:53:34.076917
512	2026-08-16 16:53:34.096482	397	246	2026-08-16 16:53:34.096482
\.


--
-- Data for Name: professionals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.professionals (id, bio, communication_rating, completed_jobs, created_at, documents_status, email, experience_years, hourly_rate_cents, latitude, location, longitude, municipality, name, neighborhood, phone, province, punctuality_rating, quality_rating, rating, response_minutes, specialty, status, updated_at, user_id, operator_notes) FROM stdin;
389	Especialista Vitaleevo com mais de 9 anos de experiencia em estruturacao de forca de vendas, implantacao de CRM e treino de alta conversao em Luanda.	4.90	142	2026-08-16 16:53:33.515437	verified	joaquim@conectaangola.ao	9	3500000	-8.916600	Talatona, Luanda	13.182900	Talatona	Joaquim Mateus	Talatona	+244 923 101 001	Luanda	4.90	5.00	4.95	10	Consultor Comercial & Supervisor de Vendas	online	2026-08-16 16:53:35.573122	531	Consultor lider de vendas e formacao comercial da Vitaleevo.
390	Experiencia em diagnostico de clima organizacional, gestao de talentos e formacao em lideranca corporativa.	5.00	104	2026-08-16 16:53:33.625162	verified	marta@conectaangola.ao	8	3000000	-8.827300	Maianga, Luanda	13.245000	Maianga	Marta Simoes	Maianga	+244 923 101 002	Luanda	4.80	5.00	4.92	15	Gestora de RH & Saude Ocupacional	online	2026-08-16 16:53:35.990228	532	\N
391	Formadora corporativa focada em dashboards executivos, KPIs automatizados, modelagem de dados no Microsoft 365 e infraestrutura de TI.	4.90	92	2026-08-16 16:53:33.697016	verified	helena@conectaangola.ao	7	3200000	-8.904000	Viana, Luanda	13.371800	Viana	Helena Costa	Viana	+244 923 101 004	Luanda	4.80	4.90	4.88	12	Especialista em Power BI & Excel Avancado	online	2026-08-16 16:53:36.481695	533	\N
392	Responsavel pela alocacao e gestao de equipas permanentes para escritorios, clinicas, condominios e higienizacao pos-obra.	4.80	88	2026-08-16 16:53:33.75618	verified	pedro@conectaangola.ao	6	2500000	-8.974100	Benfica, Luanda	13.190800	Talatona	Pedro Elias	Benfica	+244 923 101 005	Luanda	4.70	4.80	4.78	20	Coordenador de Limpeza Corporativa & Facilities	online	2026-08-16 16:53:36.880681	534	\N
394	Gestao de campanhas pagas de alta escala para concessionarias, imobiliarias e distribuicao no mercado angolano.	4.90	65	2026-08-16 16:53:33.856204	verified	manuel.kaluanda@conectaangola.ao	6	2800000	-8.835000	Alvalade, Luanda	13.242000	Maianga	Manuel Kaluanda	Alvalade	+244 923 101 015	Luanda	4.80	4.90	4.89	14	Gestor de Trafego & Meta/Google Ads	online	2026-08-16 16:53:37.595429	536	\N
395	Criacao de identidade visual completa, catalogos corporativos, apresentacoes executivas e design para redes sociais.	4.90	74	2026-08-16 16:53:33.909663	verified	carla.ndala@conectaangola.ao	7	2600000	-8.808000	Miramar, Luanda	13.246000	Sambizanga	Carla Ndala	Miramar	+244 923 101 016	Luanda	4.80	5.00	4.91	16	Designer Grafico Senior & Branding	online	2026-08-16 16:53:37.922118	537	\N
396	Implantacao de softwares de CRM, integracao de funis de vendas, WhatsApp corporativo e apoio tecnologico a PMEs.	4.90	79	2026-08-16 16:53:33.966271	verified	samuel@conectaangola.ao	7	3000000	-5.550000	Cabinda, Cabinda	12.200000	Cabinda	Samuel Bumba	Chibodo	+244 923 101 010	Cabinda	4.80	4.80	4.82	22	Consultor de CRM & Automacao	online	2026-08-16 16:53:38.328293	538	\N
397	Supervisao de redes hidraulicas e manutencao preventiva para edificios corporativos.	4.80	154	2026-08-16 16:53:34.022932	verified	carlos@conectaangola.ao	11	1850000	-8.995700	Kilamba, Luanda	13.264400	Kilamba	Carlos Vunge	Kilamba	+244 923 101 003	Luanda	4.60	4.70	4.70	28	Tecnico Senior de Facilities	occupied	2026-08-16 16:53:38.802886	539	\N
393	Auditoria de contratos de trabalho, retencao de talentos, regulacao laboral em Angola e estruturacao de politicas corporativas.	5.00	97	2026-08-16 16:53:33.7967	verified	adriana@conectaangola.ao	9	4000000	-8.814700	Ingombota, Luanda	13.230200	Ingombota	Adriana Paulo	Ingombota	+244 923 101 006	Luanda	5.00	5.00	5.00	18	Advogada & Consultora de Compliance	online	2026-08-16 16:53:40.53052	535	\N
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews (id, client_id, comment, communication, created_at, professional_id, punctuality, quality, service_request_id, updated_at) FROM stdin;
121	166	Excelente trabalho da equipa Vitaleevo. Auditoria precisa e contrato entregue rigorosamente no prazo.	5	2026-08-16 16:53:40.49867	393	5	5	187	2026-08-16 16:53:40.49867
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
20260602180000
20260601103000
20260601100000
20260601093000
20260601092045
20260524120000
20260524104500
20260524102846
20260524062000
20260603103000
20260603154500
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_categories (id, average_duration_minutes, base_price_cents, created_at, description, name, slug, updated_at, urgent_available) FROM stdin;
235	240	50000000	2026-08-16 16:53:33.24467	Tecnicas de vendas, atendimento de alto impacto, negociacao estrategica, CRM e fecho comercial.	Formacao Comercial & Vendas	formacao-corporativa-vendas	2026-08-16 16:53:33.24467	t
236	180	45000000	2026-08-16 16:53:33.268983	Gestao profissional de redes sociais, campanhas Meta Ads, Google Ads e geracao de leads para empresas.	Marketing Digital & Trafego	formacao-marketing-digital	2026-08-16 16:53:33.268983	t
237	180	35000000	2026-08-16 16:53:33.2893	Criacao de identidade visual, Canva, Photoshop, Illustrator e materiais promocionais corporativos.	Design Grafico & Branding	design-grafico-branding	2026-08-16 16:53:33.2893	t
238	180	40000000	2026-08-16 16:53:33.301953	Modelagem de dados, dashboards gerenciais no Power BI, funcoes avancadas de Excel e Microsoft 365.	Excel Avancado & Power BI	excel-power-bi-m365	2026-08-16 16:53:33.301953	t
239	240	60000000	2026-08-16 16:53:33.328148	Desenvolvimento de lideres, gestao de equipas de alto rendimento, definicao de KPIs e planeamento.	Lideranca & Gestao de KPIs	lideranca-gestao-kpis	2026-08-16 16:53:33.328148	t
240	360	25000000	2026-08-16 16:53:33.343718	Formacao intensiva de 30, 60 e 90 dias para jovens licenciados e criacao de talentos corporativos.	Academia Vitaleevo	academia-vitaleevo	2026-08-16 16:53:33.343718	f
241	480	300000000	2026-08-16 16:53:33.367645	Alocacao de equipas de vendas com supervisao Vitaleevo (Pacote Sales Team e Promotores).	Outsourcing Forca de Vendas	outsourcing-forca-vendas	2026-08-16 16:53:33.367645	t
242	480	80000000	2026-08-16 16:53:33.384478	Pacote Marketing Team com 1 Designer + 1 Gestor de Redes Sociais com supervisao estrategica.	Outsourcing Marketing & Design	outsourcing-marketing-design	2026-08-16 16:53:33.384478	t
243	360	35000000	2026-08-16 16:53:33.404333	Higienizacao de escritorios, clinicas, escolas, bancos, condominios e equipas permanentes.	Limpeza Corporativa & Pos-Obra	limpeza-corporativa	2026-08-16 16:53:33.404333	t
244	300	120000000	2026-08-16 16:53:33.41864	Diagnostico profundo de vendas, produtividade, tecnologia e processos com plano de acao imediato.	Auditoria & Diagnostico 360	consultoria-diagnostico-360	2026-08-16 16:53:33.41864	t
245	100	4000000	2026-08-16 16:53:33.437324	Configuracao de redes, suporte a computadores, infraestrutura, cameras IP e ciberseguranca.	TI e redes	ti-redes	2026-08-16 16:53:33.437324	t
246	90	3500000	2026-08-16 16:53:33.454971	Reparos residenciais e empresariais, quadros, geradores e manutencao preventiva.	Manutencao eletrica	manutencao-eletrica	2026-08-16 16:53:33.454971	t
247	120	3000000	2026-08-16 16:53:33.471875	Fugas, instalacoes hidraulicas, bombas de agua e manutencao preventiva.	Canalizacao	canalizacao	2026-08-16 16:53:33.471875	t
248	60	4500000	2026-08-16 16:53:33.484776	Enfermagem, cuidados programados, medicina ocupacional e apoio familiar.	Saude ao domicilio	saude-ao-domicilio	2026-08-16 16:53:33.484776	t
249	60	5500000	2026-08-16 16:53:33.502106	Contratos de trabalho, compliance empresarial, pareceres e apoio regulatorio.	Consultoria juridica	consultoria-juridica	2026-08-16 16:53:33.502106	t
\.


--
-- Data for Name: service_request_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_request_attachments (id, byte_size, content_type, created_at, original_filename, service_request_id, updated_at) FROM stdin;
\.


--
-- Data for Name: service_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_requests (id, accepted_at, budget_cents, client_id, code, completed_at, created_at, description, latitude, location, longitude, municipality, neighborhood, operator_notes, professional_id, province, scheduled_at, service_category_id, started_at, status, title, updated_at, urgency) FROM stdin;
186	\N	450000000	168	OS-260816-B084A7	\N	2026-08-16 16:53:40.403229	Auditoria comercial completa, treino intensivo de tecnicas de fecho, implantacao de CRM de vendas e definicao de metas com KPIs para a equipa da concessionaria.	-8.901000	Estrada de Catete, Viana	13.365000	Viana	Viana	\N	389	Luanda	2026-08-17 16:53:40.391837	235	\N	assigned	Pacote Comercial 360 - Treino de 12 Vendedores e Implantacao de CRM	2026-08-16 16:53:40.403229	urgent
187	\N	85000000	166	OS-260816-5436A3	2026-08-16 12:53:40.414171	2026-08-16 16:53:40.426202	Revisao integral de termos de prestacao de servico, politicas laborais e conformidade regulatoria.	-8.814000	Rua Major Kanhangulo, Ingombota	13.231400	Ingombota	Ingombota	\N	393	Luanda	2026-08-15 16:53:40.413989	249	\N	completed	Auditoria e Revisao de Contratos de Outsourcing	2026-08-16 16:53:40.426202	normal
188	\N	180000000	167	OS-260816-6BFE5D	\N	2026-08-16 16:53:40.443522	Alocacao mensal de equipa treinada com produtos certificados de desinfeccao e supervisao quinzenal Vitaleevo.	-8.885000	Avenida 21 de Janeiro, Morro Bento	13.201000	Talatona	Morro Bento	\N	392	Luanda	2026-08-18 08:00:00	243	\N	accepted	Equipa Permanente de Limpeza Hospitalar (4 Operadoras)	2026-08-16 16:53:40.443522	priority
189	\N	40000000	165	OS-260816-E16CE9	\N	2026-08-16 16:53:40.466959	Capacitacao executiva individual para criacao de relatorios automatizados e analise de demonstracoes de resultados.	-8.918200	Condominio Atlantico, Talatona	13.185000	\N	Talatona	\N	391	\N	2026-08-19 10:00:00	238	\N	pending	Formacao Executiva em Power BI e Dashboards Financeiros	2026-08-16 16:53:40.466959	normal
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, active, created_at, email, encrypted_password, name, remember_created_at, reset_password_sent_at, reset_password_token, role, updated_at) FROM stdin;
528	t	2026-08-16 16:53:34.528214	admin@conectaangola.ao	$2a$12$9QCP9gjc0bxhZsKtOPj9UOt8jSj9RnSadvDJcQZisDx0XyHRE8jyu	Administrador Vitaleevo	\N	\N	\N	admin	2026-08-16 16:53:34.528214
529	t	2026-08-16 16:53:34.864108	admin@vitaleevo.ao	$2a$12$UQsPKB4lISrn8j.ftSGA0eN8NHhq9nC51i2fD8fAE6jR6EEd1/2Ue	Direção Geral Vitaleevo	\N	\N	\N	admin	2026-08-16 16:53:34.864108
530	t	2026-08-16 16:53:35.209619	operador@conectaangola.ao	$2a$12$Lun0Oktjd1Dr/XcogL7LOuEawl3tf9QtagvhOz3kjHuafYq6k2yS6	Operador Luanda Vitaleevo	\N	\N	\N	operator	2026-08-16 16:53:35.209619
531	t	2026-08-16 16:53:35.564289	joaquim@conectaangola.ao	$2a$12$j2ewKl2aGsz4O1x1UH1nXuRLpeVOXpQBlx28WqZ0m.rgHo9ua2xFe	Joaquim Mateus	\N	\N	\N	professional	2026-08-16 16:53:35.564289
532	t	2026-08-16 16:53:35.976416	marta@conectaangola.ao	$2a$12$9c0uca.dWDJ2MhyHCgVkO.CXNL6uQiFE3G2eXBEVMjFeeFH0iqTd2	Marta Simoes	\N	\N	\N	professional	2026-08-16 16:53:35.976416
533	t	2026-08-16 16:53:36.467581	helena@conectaangola.ao	$2a$12$dhTXfcr0V7l18LWMFy9VFO6oS9FmG.kB3x562aj7NycowmdPcZckO	Helena Costa	\N	\N	\N	professional	2026-08-16 16:53:36.467581
534	t	2026-08-16 16:53:36.865127	pedro@conectaangola.ao	$2a$12$56wql8n.tnjU1b4eRfonEebxi/ufzoTD9hYJdFxdRz9q8PmfInluG	Pedro Elias	\N	\N	\N	professional	2026-08-16 16:53:36.865127
535	t	2026-08-16 16:53:37.233857	adriana@conectaangola.ao	$2a$12$QS7pgmImiZ3Kh.982a1FoOIw4.UvMXzSQVFQaL2KEG53DQoF9MAGm	Adriana Paulo	\N	\N	\N	professional	2026-08-16 16:53:37.233857
536	t	2026-08-16 16:53:37.583025	manuel.kaluanda@conectaangola.ao	$2a$12$Dh923GdtYxQJrGbGZQ57ouk4COvYGkfSfau1ofK9QgE/lEHYg9cEG	Manuel Kaluanda	\N	\N	\N	professional	2026-08-16 16:53:37.583025
537	t	2026-08-16 16:53:37.91271	carla.ndala@conectaangola.ao	$2a$12$jkV4QPcQ5jLJugrGfUL5pOIicpVxsyvV6s0eXkJLcsyu3oQ7uwmpS	Carla Ndala	\N	\N	\N	professional	2026-08-16 16:53:37.91271
538	t	2026-08-16 16:53:38.311604	samuel@conectaangola.ao	$2a$12$I2rz/6ZUL8fMbU/PjquNAOTYYzF6.9.kOBpXRH.q4Xba0udnnYJwO	Samuel Bumba	\N	\N	\N	professional	2026-08-16 16:53:38.311604
539	t	2026-08-16 16:53:38.767119	carlos@conectaangola.ao	$2a$12$kjpTxMFQEAJhFzW1q9fwlezHC/EPIsEe1aCA101yKdM9pWUHcBXl.	Carlos Vunge	\N	\N	\N	professional	2026-08-16 16:53:38.767119
540	t	2026-08-16 16:53:39.183534	ana.manuel@example.com	$2a$12$M8QDgqomXkeCA2EvEiJdpO48CLjV4Zbin4vu3COANjZduxuPuibNa	Ana Manuel	\N	\N	\N	client	2026-08-16 16:53:39.183534
541	t	2026-08-16 16:53:39.582237	operacoes@kiala.co.ao	$2a$12$YAJz5hmyEIpQ3MJVwC1td.NrkSdvWtaScAX/Rgq.cNYGAUfvorhaK	Kiala Comercio & Distribuicao	\N	\N	\N	client	2026-08-16 16:53:39.582237
542	t	2026-08-16 16:53:39.938089	direcao@luandacare.co.ao	$2a$12$bxcPfVH0C/T31VYHl8LJOuWlOiPPXhMEUEw8k1ni6VwKIU/g8uNQC	Clinica Luanda Care	\N	\N	\N	client	2026-08-16 16:53:39.938089
543	t	2026-08-16 16:53:40.355139	vendas@autoangola.co.ao	$2a$12$hEwJw14FICOc/WM0Qples.Tn7gT94hgsU0A5TNr5ky5kfc..cnvGG	AutoAngola Concessionaria	\N	\N	\N	client	2026-08-16 16:53:40.355139
\.


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.active_storage_attachments_id_seq', 1, true);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.active_storage_blobs_id_seq', 1, true);


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.active_storage_variant_records_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 52, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clients_id_seq', 168, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 124, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 121, true);


--
-- Name: professional_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.professional_documents_id_seq', 1, false);


--
-- Name: professional_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.professional_services_id_seq', 512, true);


--
-- Name: professionals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.professionals_id_seq', 397, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reviews_id_seq', 121, true);


--
-- Name: service_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_categories_id_seq', 249, true);


--
-- Name: service_request_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_request_attachments_id_seq', 1, true);


--
-- Name: service_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_requests_id_seq', 189, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 543, true);


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: active_storage_variant_records active_storage_variant_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT active_storage_variant_records_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: professional_documents professional_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_documents
    ADD CONSTRAINT professional_documents_pkey PRIMARY KEY (id);


--
-- Name: professional_services professional_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_services
    ADD CONSTRAINT professional_services_pkey PRIMARY KEY (id);


--
-- Name: professionals professionals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professionals
    ADD CONSTRAINT professionals_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_pkey PRIMARY KEY (id);


--
-- Name: service_request_attachments service_request_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_request_attachments
    ADD CONSTRAINT service_request_attachments_pkey PRIMARY KEY (id);


--
-- Name: service_requests service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_on_professional_id_service_category_id_1b252270c0; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_on_professional_id_service_category_id_1b252270c0 ON public.professional_services USING btree (professional_id, service_category_id);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_active_storage_variant_records_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_active_storage_variant_records_uniqueness ON public.active_storage_variant_records USING btree (blob_id, variation_digest);


--
-- Name: index_audit_logs_on_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_audit_logs_on_action ON public.audit_logs USING btree (action);


--
-- Name: index_audit_logs_on_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_audit_logs_on_actor_id ON public.audit_logs USING btree (actor_id);


--
-- Name: index_audit_logs_on_auditable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_audit_logs_on_auditable ON public.audit_logs USING btree (auditable_type, auditable_id);


--
-- Name: index_audit_logs_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_audit_logs_on_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: index_clients_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_clients_on_email ON public.clients USING btree (email);


--
-- Name: index_clients_on_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_clients_on_phone ON public.clients USING btree (phone);


--
-- Name: index_clients_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_clients_on_user_id ON public.clients USING btree (user_id);


--
-- Name: index_notifications_on_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_channel ON public.notifications USING btree (channel);


--
-- Name: index_notifications_on_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_event ON public.notifications USING btree (event);


--
-- Name: index_payments_on_service_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_payments_on_service_request_id ON public.payments USING btree (service_request_id);


--
-- Name: index_payments_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_payments_on_status ON public.payments USING btree (status);


--
-- Name: index_professional_documents_on_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professional_documents_on_kind ON public.professional_documents USING btree (kind);


--
-- Name: index_professional_documents_on_professional_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professional_documents_on_professional_id ON public.professional_documents USING btree (professional_id);


--
-- Name: index_professional_documents_on_reviewed_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professional_documents_on_reviewed_by_id ON public.professional_documents USING btree (reviewed_by_id);


--
-- Name: index_professional_documents_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professional_documents_on_status ON public.professional_documents USING btree (status);


--
-- Name: index_professional_services_on_professional_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professional_services_on_professional_id ON public.professional_services USING btree (professional_id);


--
-- Name: index_professional_services_on_service_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professional_services_on_service_category_id ON public.professional_services USING btree (service_category_id);


--
-- Name: index_professionals_on_documents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professionals_on_documents_status ON public.professionals USING btree (documents_status);


--
-- Name: index_professionals_on_municipality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professionals_on_municipality ON public.professionals USING btree (municipality);


--
-- Name: index_professionals_on_neighborhood; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professionals_on_neighborhood ON public.professionals USING btree (neighborhood);


--
-- Name: index_professionals_on_province; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professionals_on_province ON public.professionals USING btree (province);


--
-- Name: index_professionals_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_professionals_on_status ON public.professionals USING btree (status);


--
-- Name: index_professionals_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_professionals_on_user_id ON public.professionals USING btree (user_id);


--
-- Name: index_reviews_on_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reviews_on_client_id ON public.reviews USING btree (client_id);


--
-- Name: index_reviews_on_professional_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reviews_on_professional_id ON public.reviews USING btree (professional_id);


--
-- Name: index_reviews_on_service_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_reviews_on_service_request_id ON public.reviews USING btree (service_request_id);


--
-- Name: index_service_categories_on_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_service_categories_on_slug ON public.service_categories USING btree (slug);


--
-- Name: index_service_request_attachments_on_content_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_request_attachments_on_content_type ON public.service_request_attachments USING btree (content_type);


--
-- Name: index_service_request_attachments_on_service_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_request_attachments_on_service_request_id ON public.service_request_attachments USING btree (service_request_id);


--
-- Name: index_service_requests_on_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_requests_on_client_id ON public.service_requests USING btree (client_id);


--
-- Name: index_service_requests_on_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_service_requests_on_code ON public.service_requests USING btree (code);


--
-- Name: index_service_requests_on_municipality; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_requests_on_municipality ON public.service_requests USING btree (municipality);


--
-- Name: index_service_requests_on_professional_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_requests_on_professional_id ON public.service_requests USING btree (professional_id);


--
-- Name: index_service_requests_on_province; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_requests_on_province ON public.service_requests USING btree (province);


--
-- Name: index_service_requests_on_service_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_requests_on_service_category_id ON public.service_requests USING btree (service_category_id);


--
-- Name: index_service_requests_on_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_requests_on_status ON public.service_requests USING btree (status);


--
-- Name: index_service_requests_on_urgency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_service_requests_on_urgency ON public.service_requests USING btree (urgency);


--
-- Name: index_users_on_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_active ON public.users USING btree (active);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_users_on_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_role ON public.users USING btree (role);


--
-- Name: reviews fk_rails_09c661230e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fk_rails_09c661230e FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: clients fk_rails_21c421fd41; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT fk_rails_21c421fd41 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: service_requests fk_rails_2359529602; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT fk_rails_2359529602 FOREIGN KEY (professional_id) REFERENCES public.professionals(id);


--
-- Name: audit_logs fk_rails_2c3f85fdd5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_rails_2c3f85fdd5 FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: service_requests fk_rails_330a66d7b2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT fk_rails_330a66d7b2 FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: professional_documents fk_rails_3dc07561dc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_documents
    ADD CONSTRAINT fk_rails_3dc07561dc FOREIGN KEY (professional_id) REFERENCES public.professionals(id);


--
-- Name: reviews fk_rails_4413178d93; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fk_rails_4413178d93 FOREIGN KEY (service_request_id) REFERENCES public.service_requests(id);


--
-- Name: service_request_attachments fk_rails_5e7dd34edb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_request_attachments
    ADD CONSTRAINT fk_rails_5e7dd34edb FOREIGN KEY (service_request_id) REFERENCES public.service_requests(id);


--
-- Name: professionals fk_rails_84604d2557; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professionals
    ADD CONSTRAINT fk_rails_84604d2557 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: professional_documents fk_rails_86c9fed14b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_documents
    ADD CONSTRAINT fk_rails_86c9fed14b FOREIGN KEY (reviewed_by_id) REFERENCES public.users(id);


--
-- Name: professional_services fk_rails_8f7e996dce; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_services
    ADD CONSTRAINT fk_rails_8f7e996dce FOREIGN KEY (service_category_id) REFERENCES public.service_categories(id);


--
-- Name: active_storage_variant_records fk_rails_993965df05; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT fk_rails_993965df05 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: payments fk_rails_a25dff6825; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT fk_rails_a25dff6825 FOREIGN KEY (service_request_id) REFERENCES public.service_requests(id);


--
-- Name: service_requests fk_rails_b0073b2848; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT fk_rails_b0073b2848 FOREIGN KEY (service_category_id) REFERENCES public.service_categories(id);


--
-- Name: reviews fk_rails_b19e961df9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fk_rails_b19e961df9 FOREIGN KEY (professional_id) REFERENCES public.professionals(id);


--
-- Name: professional_services fk_rails_bbf2eb5b6c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.professional_services
    ADD CONSTRAINT fk_rails_bbf2eb5b6c FOREIGN KEY (professional_id) REFERENCES public.professionals(id);


--
-- Name: active_storage_attachments fk_rails_c3b3935057; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT fk_rails_c3b3935057 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 9fWnEUrcHTO6YXshs0WkM5dWTtgTbgZdiCuGfYNWIaTryrAheePuLkzdroJ0PDu

